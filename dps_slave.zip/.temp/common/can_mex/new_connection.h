#ifndef __DPS_NEW_CONNECTION_MEX__
#define __DPS_NEW_CONNECTION_MEX__

#include "base_mex_components/base_payload.h"
DPS_TYPEDEF(struct{
        }, new_connection)

#endif // !__DPS_NEW_CONNECTION_MEX__
