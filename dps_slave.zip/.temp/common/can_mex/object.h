#ifndef __DPS_OBJECT__
#define __DPS_OBJECT__

#include <stdint.h>

#include "base_mex_components/mex_types.h"
#include "base_mex_components/base_payload.h"
#include "base_mex_components/obj_id.h"

#define NAME_MAX_SIZE CAN_MAX_SIZE_MEX - sizeof(ObjectId)

DPS_TYPEDEF(
        struct{
        ObjectId obj_id;
        char name[NAME_MAX_SIZE];
        }, ObjName);

#endif // !__DPS_OBJECT__
