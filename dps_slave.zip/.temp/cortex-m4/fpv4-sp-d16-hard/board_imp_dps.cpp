#include "cortex_m4_fvp_dps_slave.h"
#include <Arduino.h>
#include <Arduino_CAN.h>
#include <stdlib.h>

//private
static int cortex_can_send(CanMessage* mex){
    CanMsg msg(CanStandardId(mex->id), mex->dlc, mex->rawMex.raw_buffer);
    char rc = personal_can.write(msg);
    if (rc < 0)
    {
        Serial.print("CAN.write(...) failed with error code ");
        Serial.println(rc);
    }
    delay(10);
    return EXIT_SUCCESS;
}

//public
int dps_init_board_specific(BoardName *board_name)
{
    return dps_init(cortex_can_send, board_name);
}
