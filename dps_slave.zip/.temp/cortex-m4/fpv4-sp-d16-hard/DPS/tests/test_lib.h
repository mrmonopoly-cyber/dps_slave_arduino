#ifndef __DPS_TEST_LIB__
#define __DPS_TEST_LIB__

void PASSED(char *mex);
void FAILED(char *mex);

void print_SCORE();

#endif // !__DPS_TEST_LIB__
