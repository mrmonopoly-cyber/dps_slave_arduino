#ifndef __DPS_DUMMY_MEX__
#define __DPS_DUMMY_MEX__

#include "base_mex_components/base_payload.h"
DPS_TYPEDEF(struct{
        }, DUMMY_NAME)

#endif // !__DPS_DUMMY_MEX__
